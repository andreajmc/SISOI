void printString(char *chars);
void readString(char *buffer);
void readSector(char *buffer, int sector);
void handleInterrupt21(int ax, int bx, int cx, int dx);
void backspace();
int div(int x, int y);
int mod(int x, int y);



int main() {
  char buffer[512];
  char line[80];
  printString("Hello World! \n");
  makeInterrupt21(); // Establecemos el handler de interrupciones 
  interrupt(0x21, 3, line, 0, 0); // Ejemplo que imprime error por parametro AX incorrecto
  interrupt(0x21, 2, buffer, 30, 0); // Lee el texto en el sector 30 de memoria y lo imprime.
  interrupt(0x21, 0, buffer, 0, 0);
  // Permite escribir una cadena y espera hasta apretar ENTER para imprimirlar
  interrupt(0x21, 1, line, 0, 0);
  interrupt(0x21, 0, line, 0, 0);
  loadProgram(); // Carga programa que prueba la API de syscalls.
  while (1) {}
  return 0;
}

/* Metodo que imprime en pantalla una cadena dependiendo de donde este el
 cursor. Utilizamos una sola interrupcion, pero dependiendo de los parametros se hace una accion diferente. */

void printString(char *chars) {
  for (; *chars != '\0'; chars++) {
    if (*chars == 0xa) {
      interrupt(0x10, 0xe * 256 + 0xd, 0, 0, 0);
    }
    interrupt(0x10, 0xe * 256 + *chars, 0, 0, 0);
  }
}

/* Este metodo lee input de usuario, esperando a que se aprete la tecla ENTER para empezar a leer. Agrega un caracter de final de linea para poder leerse de manera ordenada. Tambien soporta la funcion de backspace siempre y cuando se este en una misma linea.
*/

void readString(char *buffer) {
  char key;
  int i;
  key = interrupt(0x16, 0, 0, 0, 0);
  i = 0;
  while (key != 0xd && i < 78) {
    if (key == 0x8) {
      if (i > 0) {
        backspace();
        i--;
      }
      key = interrupt(0x16, 0, 0, 0, 0);
      continue;
    }
    interrupt(0x10, 0xe * 256 + key, 0, 0, 0);
    *(buffer + i) = key;
    i++;
    key = interrupt(0x16, 0, 0, 0, 0);
  }
  interrupt(0x10, 0xe * 256 + 0xd, 0, 0, 0);
  interrupt(0x10, 0xe * 256 + 0xa, 0, 0, 0);
  *(buffer + i) = 0xa;
  *(buffer + i + 1) = 0x0;
}

/* Lee un sector de la memoria, en este caso un txt file.
  AX = AL + AH x 256
  BX = BL + BH x 256
  CX = CL + CH x 256
  DX = DL + DH x 256
*/
void readSector(char *buffer, int sector) {
  interrupt(0x13, 2 * 256 + 1,
    buffer,
    div(sector, 36) * 256 + mod(sector, 18) + 1,
    mod(div(sector, 18), 2) * 256 + 0);
}

/* Cada vez que una interrupcion 0x21 ocurre, se llama a esta funcion. Basicamente esta funcion hace uso de la funcion interrupt ya dada para generar las acciones deseadas, en lugar de tener que crear en el kernel metodos especificos. Antes de esta funcion, siempre se debe llamar a makeInterrupt21() para generar la interrupcion.

Los posibles casos de ejecucion son

  if AX = 0:
    Se lee el string guardado en el registro BX. (Caso Hola Mundo, se manda un String)
  if AX = 1:
    Se ejecuta la funcion Read String (user input) mandando un buffer como parametro BX.
  if AX = 2:
    Se ejecuta readSector, enviando un buffer al registro BX y un sector en el registro CX.
  Else:
    Mensaje de parametro incorrecto.
*/

void handleInterrupt21(int ax, int bx, int cx, int dx) {
  if (ax == 0) {
    printString((char *) bx);
  } else if (ax == 1) {
    readString((char *) bx);
  } else if (ax == 2) {
    readSector((char *) bx, cx);
  } else {
    printString("Error: invalid ax to handleInterrupt21!.\n");
  }
}

/* Sobrescribe lo que antes estaba y reemplaza con un espacion en blanco. */
void backspace() {
  interrupt(0x10, 0xe * 256 + 0x8, 0, 0, 0);
  interrupt(0x10, 0xe * 256 + ' ', 0, 0, 0);
  interrupt(0x10, 0xe * 256 + 0x8, 0, 0, 0);
}

int div(int x, int y) {
  int quo;
  for (quo = 0; (quo + 1) * y <= x; quo++) {}
  return quo;
}

int mod(int x, int y) {
  for (; x >= y; x -= y) {}
  return x;
}
