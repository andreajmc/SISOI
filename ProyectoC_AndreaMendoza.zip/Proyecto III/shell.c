int getCommandId(char *command);
int isTypeCommand(char *command);
int isExecuteCommand(char *command);
void typeCommand(char *line);
void executeCommand(char *line);
void fillPromptName(char *buffer);
void fillErrorMessage(char *buffer);

int main() {
  char line[80], prompt[9], error[19];
  int command, segment;
  fillPromptName(prompt);
  fillErrorMessage(error);

  while (1) {
    interrupt(0x21, 0, prompt, 0, 0);
    interrupt(0x21, 1, line, 0, 0);
    command = getCommandId(line);
    if (command == 1) {
      /* Llamar a comando type */
      typeCommand(line);
    } else if (command == 2) {
      /* Ejecutar el programa deseado */
      executeCommand(line);
    } else if (line[0] != 0xa || line[1] != 0x0) {
      /* Error de comando */
      interrupt(0x21, 0, error, 0, 0);
    }
  }
  return 0;
}

void typeCommand(char *line) {
  char fileName[7], buffer[13312];
  int i;
  for (i = 0; i < 6; i++) {
    fileName[i] = line[5 + i];
  }
  fileName[6] = '\0';
  interrupt(0x21, 3, fileName, buffer, 0);
  interrupt(0x21, 0, buffer, 0, 0);
}

void executeCommand(char *line) {
  char fileName[7];
  int i;
  for (i = 0; i < 6; i++) {
    fileName[i] = line[8 + i];
  }
  fileName[6] = '\0';
  interrupt(0x21, 4, fileName, 0x2000, 0);
}

int getCommandId(char *command) {
  if (isTypeCommand(command) == 1) {
    return 1;
  } else if (isExecuteCommand(command) == 1) {
    return 2;
  }
  return 0;
}

int isTypeCommand(char *command) {
  if (command[0] == 't' && command[1] == 'y' && command[2] == 'p'
    && command[3] == 'e' && command[4] == ' ' && command[11] == 0xa
    && command[12] == 0x0) {
    return 1;
  }
  return 0;
}

int isExecuteCommand(char *command) {
  if (command[0] == 'e' && command[1] == 'x' && command[2] == 'e'
    && command[3] == 'c' && command[4] == 'u' && command[5] == 't'
    && command[6] == 'e' && command[7] == ' '
    && command[14] == 0xa
    && command[15] == 0x0) {
    return 1;
  }
  return 0;
}

void fillPromptName(char *buffer) {
  buffer[0] = 'S';
  buffer[1] = 'H';
  buffer[2] = 'E';
  buffer[3] = 'L';
  buffer[4] = 'L';
  buffer[5] = ':';
  buffer[6] = '>';
  buffer[7] = ' ';
  buffer[8] = '\0';
}

void fillErrorMessage(char *buffer) {
  buffer[0] = 'E';
  buffer[1] = 'r';
  buffer[2] = 'r';
  buffer[3] = 'o';
  buffer[4] = 'r';
  buffer[5] = ' ';
  buffer[6] = 'd';
  buffer[7] = 'e';
  buffer[8] = ' ';
  buffer[9] = 'C';
  buffer[10] = 'o';
  buffer[11] = 'm';
  buffer[12] = 'a';
  buffer[13] = 'n';
  buffer[14] = 'd';
  buffer[15] = 'o';
  buffer[16] = '.';
  buffer[17] = '\n';
  buffer[18] = '\0';
}