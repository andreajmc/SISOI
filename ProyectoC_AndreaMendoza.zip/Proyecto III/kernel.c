
/* Funciones adoptadas del Proyecto B */
void printString(char *chars);
void readString(char *buffer);
void readSector(char *buffer, int sector);
void handleInterrupt21(int ax, int bx, int cx, int dx);

/* Funciones Nuevas para Proyecto C*/
void readFile(char *fileName, char *buffer);
void executeProgram(char *name, int segment);
void terminate();

int mod(int a, int b);
int div(int a, int b);
void backspace();
void loadErrorMessage(char *buffer);

int main() {
  char shell[6];
  shell[0] = 's';
  shell[1] = 'h';
  shell[2] = 'e';
  shell[3] = 'l';
  shell[4] = 'l';
  shell[5] = '\0';

  makeInterrupt21();  // Establecemos el handler de interrupciones 
  interrupt(0x21, 4, shell, 0x2000, 0);

  while (1) {}
  return 0;
}

/* Metodo que imprime en pantalla una cadena dependiendo de donde este el cursor. Utilizamos una sola interrupcion, pero dependiendo de los parametros se hace una accion diferente. */

void printString(char *chars) {
  for (; *chars != '\0'; chars++) {
    if (*chars == 0xa) {
      interrupt(0x10, 0xe * 256 + 0xd, 0, 0, 0);
    }
    interrupt(0x10, 0xe * 256 + *chars, 0, 0, 0);
  }
}

/* Lee y guarda en buffer lo que es ingresado a traves del teclado. Cuando se apreta la tecla ENTER, deja
de escuchar. Al apretar un backspace, como ya habia sido implementado anteriormente, se borra el char del
buffer y se sobrescribe. Cuando ya no hay mas chars que borrar, el cursor permanece es la misma posicion.

(No borra mas alla de lo que el usuario comenzo a escribir.
*/
void readString(char *buffer) {
  char key;
  int i;
  key = interrupt(0x16, 0, 0, 0, 0);
  i = 0;
  while (key != 0xd && i < 78) {
    if (key == 0x8) {
      if (i > 0) {
        backspace();
        i--;
      }
      key = interrupt(0x16, 0, 0, 0, 0);
      continue;
    }
    interrupt(0x10, 0xe * 256 + key, 0, 0, 0);
    *(buffer + i) = key;
    i++;
    key = interrupt(0x16, 0, 0, 0, 0);
  }
  interrupt(0x10, 0xe * 256 + 0xd, 0, 0, 0);
  interrupt(0x10, 0xe * 256 + 0xa, 0, 0, 0);
  *(buffer + i) = 0xa;
  *(buffer + i + 1) = 0x0;
}

/* Lee un sector de la memoria, en este caso un txt file.
  AX = AL + AH x 256
  BX = BL + BH x 256
  CX = CL + CH x 256
  DX = DL + DH x 256
*/

void readSector(char *buffer, int sector) {
  interrupt(0x13, 2 * 256 + 1,
    buffer,
    div(sector, 36) * 256 + mod(sector, 18) + 1,
    mod(div(sector, 18), 2) * 256 + 0);
}

/* Cada vez que una interrupcion 0x21 ocurre, se llama a esta funcion. Basicamente esta funcion hace uso de la funcion interrupt ya dada para generar las acciones deseadas, en lugar de tener que crear en el kernel metodos especificos. Antes de esta funcion, siempre se debe llamar a makeInterrupt21() para generar la interrupcion.

Los posibles casos de ejecucion son

  if AX = 0:
    Se lee el string guardado en el registro BX. (Caso Hola Mundo, se manda un String)
  if AX = 1:
    Se ejecuta la funcion Read String (user input) mandando un buffer como parametro BX.
  if AX = 2:
    Se ejecuta readSector, enviando un buffer al registro BX y un sector en el registro CX.
  Else:
    Mensaje de parametro incorrecto.
*/

void handleInterrupt21(int ax, int bx, int cx, int dx) {
  char error[19];
  loadErrorMessage(error);
  if (ax == 0) {
    printString((char *) bx);
  } else if (ax == 1) {
    readString((char *) bx);
  } else if (ax == 2) {
    readSector((char *) bx, cx);
  } else if (ax == 3) {
    readFile((char *) bx, (char *) cx);
  } else if (ax == 4) {
    executeProgram((char *) bx, cx);
  } else if (ax == 5) {
    terminate();
  } else {
    printString(error);
  }
}

void readFile(char *fileName, char *buffer) {
  char directory[512];
  int i, j, sector;
  readSector(directory, 2);

  for (i = 0; i < 512; i += 32) {
    for (j = 0; j < 6; j++) {
      if (fileName[j] != directory[i + j]) {
        break;
      }
    }
    if (j == 6) {
      for (j = 0; j < 26; j++) {
        sector = (int) directory[i + 6 + j];
        if (sector == 0) {
          break;
        }
        readSector(buffer + 512 * j, sector);
      }
      break;
    }
  }
  if (i == 512) {
    return;
  }
}

void executeProgram(char *name, int segment) {
  char buffer[13312];
  int address;
  readFile(name, buffer);

  for (address = 0; address < 13312; address++) {
    putInMemory(segment, address, buffer[address]);
  }

  launchProgram(segment);
}

void terminate() {
  char shell[6];
  shell[0] = 's';
  shell[1] = 'h';
  shell[2] = 'e';
  shell[3] = 'l';
  shell[4] = 'l';
  shell[5] = '\0';
  interrupt(0x21, 4, shell, 0x2000, 0);
}

int div(int a, int b) {
  int quotient;
  for (quotient = 0; (quotient + 1) * b <= a; quotient++) {}
  return quotient;
}

int mod(int a, int b) {
  for (; a >= b; a -= b) {}
  return a;
}

/* Sobrescribe lo que antes estaba y reemplaza con un espacion en blanco. */

void backspace() {
  interrupt(0x10, 0xe * 256 + 0x8, 0, 0, 0);
  interrupt(0x10, 0xe * 256 + ' ', 0, 0, 0);
  interrupt(0x10, 0xe * 256 + 0x8, 0, 0, 0);
}

void loadErrorMessage(char *buffer) {
  buffer[0] = 'I';
  buffer[1] = 'n';
  buffer[2] = 't';
  buffer[3] = 'e';
  buffer[4] = 'r';
  buffer[5] = 'r';
  buffer[6] = 'u';
  buffer[7] = 'p';
  buffer[8] = 't';
  buffer[9] = 'o';
  buffer[10] = 'r';
  buffer[11] = ' ';
  buffer[12] = 'I';
  buffer[13] = 'n';
  buffer[14] = 'v';
  buffer[15] = 'a';
  buffer[16] = 'l';
  buffer[17] = 'i';
  buffer[18] = 'd';
  buffer[19] = 'o';
  buffer[20] = '\n';
  buffer[21] = '\0';
}